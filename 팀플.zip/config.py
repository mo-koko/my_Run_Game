from PIL import Image

screen = {
    "width": 1200,
    "height": 720,
    "title": "Run Game",
}


