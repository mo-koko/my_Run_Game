import random


import arcade

from config import screen
from sprite import big, fast, heart, hero, up, vatility, down

class Game(arcade.Window):
    def __init__(self):
        super().__init__(
            screen["width"], screen["height"], screen["title"], resizable=False
        )

    def setup(self):
        
        self.is_run = 0
        
        self.is_small = 0
        
        self.stand_img = "src/images/character.png"
        self.run_img = "src/images/run.png"
        
        self.gravity = 1.8

        # object
        self.character = hero()
        self.wall = up()
        self.fast_item = fast()
        self.big_item = big()
        self.vitality_item = vatility()
        self.life = heart()
        self.huddle = down()

        # background        img object
        background_image = "src/images/map.png"
        self.background = arcade.load_texture(background_image)
        self.background_x1_pos = screen["width"] // 2
        self.backgorund_dx = 8
        self.background_x1_pos -= self.backgorund_dx
        self.background_y1_pos = screen["height"] // 2

        self.background2 = arcade.load_texture(background_image)
        self.background_x2_pos = screen["width"] * 1.5
        self.background_y2_pos = screen["height"] // 2

        self.acceleration = 1
        self.acceleration += self.acceleration

        # bgm
        self.bgm = None
        self.bgm_ing = False

        self.is_fast = 0
        self.is_large = 0

        
        self.is_col = 0
        
        self.total_game_time = 0
        self.dt = 0.666
        self.total_game_time += self.dt
        self.total_score = self.dt 

    def on_draw(self):  # draw object
        arcade.start_render()


        # background        self.x, self.y, width, height, object
        arcade.draw_texture_rectangle(
            self.background_x1_pos,
            self.background_y1_pos,
            screen["width"] + 40,
            screen["height"],
            self.background
        )
        arcade.draw_texture_rectangle(
            self.background_x2_pos,
            self.background_y2_pos,
            screen["width"] + 40,
            screen["height"],
            self.background2
        )


        # score
        self.total_score += self.total_game_time 
        
        arcade.draw_text(
            "SCORE : %d" % self.total_score, 1000, 650, arcade.color.WHITE, 14)

        # sprite object draw
        self.character.draw()
        self.big_item.draw()
        self.fast_item.draw()
        self.wall.draw()
        self.life.draw()
        self.vitality_item.draw()
        self.huddle.draw()
        
        if self.life.center_x <= -self.life.width // 2:
            self.total_game_time, self.dt = [0]*2
            
            arcade.draw_text(
                "GAME OVER ", screen["width"]//2 - 100 ,
                screen["height"] // 2, arcade.color.WHITE, 20)   
            
            arcade.draw_text(
                "YOUR SCORE : %d " %self.total_score, screen["width"]//2 - 130,
                screen["height"] // 2 - 50, arcade.color.WHITE, 20)      
        

    def sound(self): 

        self.bgm = arcade.load_sound("src/music/bgm.mp3")

        arcade.play_sound(self.bgm)
        self.bgm_ing = True


    def on_key_press(self, key, parameter):    
            
        if key == arcade.key.SPACE:
            self.character.jumping()

            if self.character.count_of_jump == 2:
                self.character.rotate()
                
                # 수정 필요
                if key == arcade.key.SPACE:
                    pass
                
        if key == arcade.key.DOWN:
            self.stand_img ="src/images/character_small.png"
            self.run_img ="src/images/run_small.png"
            self.is_small = 1
                      

    def on_key_release(self, key, parameter):
        
            
        if key == arcade.key.DOWN:
            self.stand_img ="src/images/character.png"        
            self.run_img ="src/images/run.png"
            self.is_small = 0

    def speed_down(self, parameter):
        self.wall.speed = 4
        self.backgorund_dx = self.speed_save
        self.is_fast = 0
        arcade.unschedule(self.speed_down)

    def restore(self, parameter):   # up_obstacle
        print("call restore")
        self.wall.angle = 0
        self.wall.center_x += screen["width"] * random.randrange(1, 2)
        self.wall.center_y = 350
        arcade.unschedule(self.restore)
        return


    def restore_2(self, parameter):     # down_obstalce
        print("call restore2")
        self.huddle.angle = 0
        self.huddle.center_x += screen["width"] * random.randrange(1, 2)
        self.huddle.center_y = 180
        arcade.unschedule(self.restore_2)
        return
    

    def large(self):
        print("large")
        self.stand_img = "src/images/character_big.png"
        self.run_img = "src/images/run_big.png"
        
        arcade.schedule(self.small, 3.0)

    def small(self, parameter):
        print("small")
        self.stand_img = "src/images/character.png"
        self.run_img = "src/images/run.png"
        self.is_large = 0
        arcade.unschedule(self.small)
        return

    def speed_up(self):
        if self.character.collides_with_sprite(self.fast_item):
            self.speed_save = self.backgorund_dx
            self.wall.speed += 8
            self.backgorund_dx += 20
            self.huddle.speed += 8

            arcade.schedule(self.speed_down, 3.0)
            return

    def on_update(self, key):
        
        
        print(self.character.bottom)
        
        # character
        self.character.update()
        self.character.change_y -= self.gravity  # gravity

        if self.character.bottom <= 0:
            self.character.bottom = 0
            self.character.count_of_jump = 0
                    
        if self.character.count_of_jump == 2:
            self.character.angle -= 10

        
        if self.character.count_of_jump == 0:
            self.character.angle = 0

       
        # character
        # 달리는 모션
        self.is_run += 1
        
        if self.total_score % 10 <= 5:
            self.character.texture = arcade.load_texture(self.stand_img)
        else:
            self.character.texture = arcade.load_texture(self.run_img)
        
        # 커지는 아이템을 먹었을 때 화면 밑으로 내려가는 현상 방지
        if self.is_large == 1:
            if self.character.bottom <= 50:
                self.character.bottom = 50
        
        if self.is_small == 1:
            if self.character.bottom >= -50:
                self.character.bottom = -50
        
            
        # bgm 반복재생
        if not self.bgm_ing:
            self.sound()

        # up_obstacle
        self.wall.update()

        if self.character.collides_with_sprite(self.wall):      # 부딪혔는지 판단
            if self.is_fast == 1 or self.is_large == 1:         # 아이템을 먹었는지 판단. 먹었으면 1 아니면 0
                self.is_col = 1                                 # 아이템을 먹었다면 is_col = 1 -> up_obstacle과 부딪힌 걸 변수로 표현

            else:
                self.wall.center_x = screen["width"] * 2
                self.life.center_x -= 50
                self.wall.angle = 0
                
        # 안 부딪혔으면 다시 앞으로 가져오기
        if self.wall.center_x <= -50:
            self.wall.center_x = screen["width"] * random.randint(2, 4)

        
        # 충돌 시 장애물 회전
        if self.is_fast == 1 or self.is_large == 1:
            if self.is_col == 1:
                self.wall.angle -= 10
                self.wall.center_x += 23
                self.wall.center_y -= 10
        
        # 아이템 지속 효과가 끝나면 장애물 원위치        
        if self.is_col == 1:                                        
            if self.is_fast == 0 and self.is_large == 0:
                self.wall.angle = 0
                self.wall.center_x = screen["width"] * 2
                self.wall.center_y = 350
                self.is_col = 0
            arcade.schedule(self.restore, 1.0)
            

        # down_obstacle
        self.huddle.update()
        if self.character.collides_with_sprite(self.huddle):        # 부딪혔는지 판단
            if self.is_fast == 1 or self.is_large == 1:             # 아이템을 먹었는지 판단
                self.is_col = 2                                     # collision with down_obstacle

            else:
                self.huddle.center_x = screen["width"] * 2          # 아이템을 안 먹었으면 체력깎
                self.life.center_x -= 50
                self.huddle.angle = 0

        
        # 안 부딪혔으면 다시 앞으로 가져오기
        if self.huddle.center_x <= -50:
            self.huddle.center_x = screen["width"] * random.randint(2, 4)
            

        # 충돌 시 장애물 회전
        if self.is_fast == 1 or self.is_large == 1:
            if self.is_col == 2:
                self.huddle.angle -= 10
                self.huddle.center_x += 23
                self.huddle.center_y -= 10
        
        # 아이템 지속 효과가 끝나면 장애물 원위치           
        if self.is_col == 2:       
            if self.is_fast == 0 and self.is_large == 0:
                self.huddle.angle = 0
                self.huddle.center_x = screen["width"] * 2
                self.huddle.center_y = 180
                self.is_col = 0
            arcade.schedule(self.restore_2, 1.0)
            

        # 장애물 텀
        if self.wall.center_x > screen["width"] -100 and self.huddle.center_x > screen["width"]-100:
            if abs(self.wall.center_x - self.huddle.center_x) <= 400:
                self.wall.center_x += 400


        
        # item

        # fast_item
        self.fast_item.update()

        if self.character.collides_with_sprite(self.fast_item):
            self.is_fast = 1
            self.speed_up()
            self.fast_item.center_x += screen["width"] * random.randrange(4, 6)

        if self.fast_item.center_x < -50:
            self.fast_item.center_x += screen["width"] * random.randrange(4, 6)

        

        # big_item
        self.big_item.update()

        if self.character.collides_with_sprite(self.big_item):
            self.is_large = 1
            self.large()
            self.big_item.center_x += screen["width"] * random.randrange(4, 6)

        if self.big_item.center_x < -50:
            self.big_item.center_x += screen["width"] * random.randrange(4, 6)

        # vitality_item
        self.vitality_item.update()
        if self.character.collides_with_sprite(self.vitality_item):
            self.life.center_x += 50
            self.vitality_item.center_x += screen["width"] * random.randrange(4, 6)

        if self.vitality_item.center_x < -50:
            self.vitality_item.center_x += screen["width"] * random.randrange(4, 6)

        # item fly
        item_speeds = [
            (self.fast_item, 2.3),
            (self.big_item, 2.3),
            (self.vitality_item, 2.3),
        ]

        for item, speed in item_speeds:
            if item.center_y <= 250:
                item.change_y = speed
            elif item.center_y >= 430:
                item.change_y = -speed

        
        # avoid overlap
        if self.big_item.center_x == self.fast_item.center_x:
            self.big_item.center_x += screen["width"]
        if self.big_item.center_x == self.vitality_item.center_x:
            self.vitality_item.center_x += screen["width"] + 300
        if self.fast_item.center_x == self.vitality_item.center_x:
            self.fast_item.center_x += screen["width"] - 200

        # life
        self.life.update()


        if self.life.center_x > self.width // 2:
            self.life.center_x = self.width // 2
        
        if self.life.center_x <= -self.life.width // 2:
            self.total_game_time, self.dt = [0]*2

            # more event
            arcade.schedule(arcade.close_window, 3.0)
            
        

        # background
        self.backgorund_dx += self.acceleration * 0.001

        self.background_x1_pos -= self.backgorund_dx
        self.background_x2_pos -= self.backgorund_dx

        if self.background_x1_pos <= -screen["width"] // 2:  # 배경이 계속 이어지도록
            self.background_x1_pos = screen["width"] * 1.5
        if self.background_x2_pos <= -screen["width"] // 2:
            self.background_x2_pos = screen["width"] * 1.5
        
        self.total_game_time = 0
        self.dt = 0.666
        if self.life.center_x > -self.life.width // 2:
            
            self.total_game_time += self.dt
        

def main():
    game = Game()
    game.setup()
    arcade.run()


if __name__ == "__main__":
    main()
