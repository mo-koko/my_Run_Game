import random

import arcade

from config import screen



class hero(arcade.Sprite):
    def __init__(self, character_img = "src/images/character.png"):       # 초기화 메서드. 인스턴스 들의 값을 초기화 시킴
        super().__init__(character_img)        # arcade.Sprite 클래스를 상속받으면서 상위 Class의 인스턴스를 초기화하면서 자체 기능도 추가가능하게

        self.center_x = 150  # center_x, center_y는 내장 인스턴스
        self.center_y = 650
        self.change_x = 0
        self.change_y = 0
        self.count_of_jump = 0
        
        self.width = 300
        self.height = 300


    def update(self):  # 움직일 때 위치값 설정
        self.center_x += self.change_x  # change_x or change_y = parameter
        self.center_y += self.change_y

    def jumping(self):
        if self.count_of_jump < 2:
            self.change_y = 26
            self.count_of_jump += 1

    def rotate(self):  # 점프 시 회전
        self.angle = 0



class up(arcade.Sprite):
    def __init__(self, wall="src/images/천장장애물.png"):
        super().__init__(wall)

        self.speed = 10
        self.center_x = screen["width"] +300 #random.randrange(2,3)
        self.center_y = 350
        self.change_x = self.speed
        self.width = 300
        self.height = 900
        self.acceleration = 0.006        # 가속도
        self.speed+= self.acceleration
        

    def update(self):
        self.center_x -= self.change_x


class down(arcade.Sprite):
    def __init__(self, huddle="src/images/바닥장애물.png"):
        super().__init__(huddle)
        
        self.speed = 10
        self.center_x = screen["width"] + 200
        self.center_y = 180
        self.width = 250
        self.height = 300
        self.change_x = self.speed
        self.acceleration = 0.006
        self.speed+= self.acceleration
        
    def update(self):
        self.center_x -= self.change_x
        
        
class fast(arcade.Sprite):
    def __init__(self, fast_item="src/images/빨간포션.png"):
        super().__init__(fast_item)

        self.speed = 4
        self.center_x = screen["width"] * random.randrange(4, 6)  # item_pos
        self.center_y = 200
        self.change_y = 2
        self.width = 150
        self.height = 150

    def update(self):
        self.center_y += self.change_y
        self.center_x -= self.speed  # speed


class big(arcade.Sprite):
    def __init__(self, big_item="src/images/파란포션.png"):
        super().__init__(big_item)

        self.speed = 4
        self.center_x = (
            screen["width"] // 2
        )   * random.randrange(4,7)        # item_pos
        self.center_y = 200
        self.change_y = 2
        self.width = 150
        self.height = 150
        
    def update(self):
        self.center_y += self.change_y
        self.center_x -= self.speed  # speed


class vatility(arcade.Sprite):  # life item
    def __init__(self, vatility_item="src/images/heart.png"):
        super().__init__(vatility_item)

        self.speed = 4
        self.center_x = screen["width"] * random.randrange(4, 7)
        self.center_y = 200
        self.change_y = 2

    def update(self):
        self.center_y += self.change_y
        self.center_x -= self.speed  # speed


class heart(arcade.Sprite):
    def __init__(self, life="src/images/생명력.png"):
        super().__init__(life)

        self.center_x = 0 + self.width // 2     #303
        self.center_y = screen["height"] - (self.height)
        self.change_x = 0.1

    def update(self):
        self.center_x -= self.change_x
